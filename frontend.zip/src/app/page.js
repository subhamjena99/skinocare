import Home from "@/Components/Home";

export default function Index() {
  return (
    <>
    <Home />
    </>
  )
}
