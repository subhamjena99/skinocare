// import Signin from "@/Components/SSO/Signin";
import Signup from "@/Components/SSO/Signup";

const SignIn = () => {
  return (
    <Signup />
  );
};

export default SignIn;