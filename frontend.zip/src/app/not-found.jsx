import React from 'react'

const notFound = () => {
  return (
    <div>Page not found</div>
  )
}

export default notFound