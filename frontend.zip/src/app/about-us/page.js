import AboutUs from "@/Components/AboutUs";

const About = () => {
  return (
    <AboutUs />
  );
};

export default About;