import ForgetPassword from "@/Components/SSO/ForgotPass/ForgetPassword";

const ForgetPass = () => {
  return (
    <ForgetPassword />
  );
};

export default ForgetPass;