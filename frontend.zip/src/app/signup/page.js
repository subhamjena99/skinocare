import Signup from "@/Components/SSO/Signup";

const SignUp = () => {
  
  return (
    <Signup />
  );
};

export default SignUp;